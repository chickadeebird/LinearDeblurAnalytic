#feature-id LinearDeblurAnalytic : ChickadeeScripts > LinearDeblurAnalytic
#feature-icon  LinearDeblurAnalytic.svg
#feature-info This script deblurs elongated stars within an image



#include "STDCommon.js"

#define VERSION "v1.0.0 beta"



// Define platform-agnostic folder paths
let pathSeparator = (CoreApplication.platform == "MSWINDOWS" || CoreApplication.platform == "Windows") ? "\\" : "/";
let scriptTempDir = File.systemTempDirectory + pathSeparator + "LinearDeblurAnalyticConfig";
let scriptConfigFile = scriptTempDir + pathSeparator + "LinearDeblurAnalytic_config.csv";

// Ensure the temp directory exists
if (!File.directoryExists(scriptTempDir)) {
   File.createDirectory(scriptTempDir);
}


// Define global parameters
var globalParameters = {
   targetView: undefined,
   targetWindow: undefined,
   strideSize: 1024,
   maxDistortion: 0.6,
   sensitivity: 0.5,
   structureLayers: 5,
   xyStretch: 1.5,
   peakResponse: 0.5,
   linearImage: true,
   replaceWithSS: true,
   keepSyntheticStars: true,
   ignoreHotPixels: true,
   SSdenoiseFirst: true,
   SSdenoiseWithNN: false,
   SSdenoiseWithMMT: true,
   SSlinearCheckBox: true,
   recombinationMethod: 'op_screen',
   SSrecombinationExtraPercent: 0.5,
   SSminimumStarSize: 0,
   starDetectorStars: [],
   dynamicPSFStars: [],
   SSstarSizeRange: 10,
   SSstarIntensityRange: 0.04,
   SSallowClusteredSources: false,
   erosionLength: 4,
   erosionIterations: 1,
   erosionAmount: 0.5,
   deconvolutionAmount: 4,
   deconvolutionIterations: 10,
   deconvolutionDeringing: false,
   deconvolutionGlobalDark: 0.1,

   save: function () {
      Parameters.set("maxDistortion", this.maxDistortion);
      Parameters.set("sensitivity", this.sensitivity);
      Parameters.set("structureLayers", this.structureLayers);
      Parameters.set("xyStretch", this.xyStretch);
      Parameters.set("peakResponse", this.peakResponse);
      Parameters.set("SSminimumStarSize", this.SSminimumStarSize);
      Parameters.set("SSdenoiseFirst", this.SSdenoiseFirst);
      Parameters.set("SSdenoiseWithNN", this.SSdenoiseWithNN);
      Parameters.set("SSdenoiseWithMMT", this.SSdenoiseWithMMT);
      Parameters.set("replaceWithSS", this.replaceWithSS);
      Parameters.set("keepSyntheticStars", this.keepSyntheticStars);
      Parameters.set("SSlinearCheckBox", this.SSlinearCheckBox);
      Parameters.set("recombinationMethod", this.recombinationMethod);
      Parameters.set("SSrecombinationExtraPercent", this.SSrecombinationExtraPercent);
      Parameters.set("SSstarIntensityRange", this.SSstarIntensityRange);
      Parameters.set("SSallowClusteredSources", this.SSallowClusteredSources);
      Parameters.set("erosionLength", this.erosionLength);
      Parameters.set("erosionIterations", this.erosionIterations);
      Parameters.set("erosionAmount", this.erosionAmount);
      Parameters.set("deconvolutionAmount", this.deconvolutionAmount);
      Parameters.set("deconvolutionIterations", this.deconvolutionIterations);
      Parameters.set("deconvolutionDeringing", this.deconvolutionDeringing);
      Parameters.set("deconvolutionGlobalDark", this.deconvolutionGlobalDark);

      this.savePathToFile();
   },

   load: function () {
      if (Parameters.has("maxDistortion"))
         this.maxDistortion = Number(Parameters.getString("maxDistortion"));
      if (Parameters.has("sensitivity"))
         this.sensitivity = Number(Parameters.getString("sensitivity"));
      if (Parameters.has("structureLayers"))
         this.structureLayers = Number(Parameters.getString("structureLayers"));
      if (Parameters.has("xyStretch"))
         this.xyStretch = Number(Parameters.getString("xyStretch"));
      if (Parameters.has("peakResponse"))
         this.peakResponse = Number(Parameters.getString("peakResponse"));
      if (Parameters.has("SSminimumStarSize"))
         this.SSminimumStarSize = Number(Parameters.getString("SSminimumStarSize"));
      if (Parameters.has("SSdenoiseFirst"))
         this.SSdenoiseFirst = Number(Parameters.getString("SSdenoiseFirst"));
      if (Parameters.has("SSdenoiseWithNN"))
         this.SSdenoiseWithNN = Number(Parameters.getString("SSdenoiseWithNN"));
      if (Parameters.has("SSdenoiseWithMMT"))
         this.SSdenoiseWithMMT = Number(Parameters.getString("SSdenoiseWithMMT"));
      if (Parameters.has("replaceWithSS"))
         this.replaceWithSS = Number(Parameters.getString("replaceWithSS"));
      if (Parameters.has("SSlinearCheckBox"))
         this.SSlinearCheckBox = Number(Parameters.getString("SSlinearCheckBox"));
      if (Parameters.has("keepSyntheticStars"))
         this.keepSyntheticStars = Number(Parameters.getString("keepSyntheticStars"));
      if (Parameters.has("recombinationMethod"))
         this.recombinationMethod = String(Parameters.getString("recombinationMethod"));
      if (Parameters.has("SSrecombinationExtraPercent"))
         this.SSrecombinationExtraPercent = Number(Parameters.getString("SSrecombinationExtraPercent"));
      if (Parameters.has("SSstarIntensityRange"))
         this.SSstarIntensityRange = Number(Parameters.getString("SSstarIntensityRange"));
      if (Parameters.has("SSallowClusteredSources"))
         this.SSallowClusteredSources = Number(Parameters.getString("SSallowClusteredSources"));
      if (Parameters.has("erosionLength"))
         this.erosionLength = Number(Parameters.getString("erosionLength"));
      if (Parameters.has("erosionIterations"))
         this.erosionIterations = Number(Parameters.getString("erosionIterations"));
      if (Parameters.has("erosionAmount"))
         this.erosionAmount = Number(Parameters.getString("erosionAmount"));
      if (Parameters.has("deconvolutionAmount"))
         this.deconvolutionAmount = Number(Parameters.getString("deconvolutionAmount"));
      if (Parameters.has("deconvolutionIterations"))
         this.deconvolutionIterations = Number(Parameters.getString("deconvolutionIterations"));
      if (Parameters.has("deconvolutionDeringing"))
         this.deconvolutionDeringing = Number(Parameters.getString("deconvolutionDeringing"));
      if (Parameters.has("deconvolutionGlobalDark"))
         this.deconvolutionGlobalDark = Number(Parameters.getString("deconvolutionGlobalDark"));

      this.loadPathFromFile();
   },
   savePathToFile: function () {
      try {
         let file = new File;
         
         file.createForWriting(scriptConfigFile);
         file.outTextLn(String(this.maxDistortion));
         file.outTextLn(String(this.sensitivity));
         file.outTextLn(String(this.structureLayers));
         file.outTextLn(String(this.xyStretch));
         file.outTextLn(String(this.peakResponse));
         file.outTextLn(String(this.SSminimumStarSize));
         file.outTextLn(String(Number(this.SSdenoiseFirst)));
         file.outTextLn(String(Number(this.SSdenoiseWithNN)));
         file.outTextLn(String(Number(this.SSdenoiseWithMMT)));
         file.outTextLn(String(Number(this.replaceWithSS)));
         file.outTextLn(String(Number(this.SSlinearCheckBox)));
         file.outTextLn(String(Number(this.keepSyntheticStars)));
         file.outTextLn(String(this.recombinationMethod));
         file.outTextLn(String(this.SSrecombinationExtraPercent));
         file.outTextLn(String(this.SSstarIntensityRange));
         file.outTextLn(String(Number(this.SSallowClusteredSources)));
         file.outTextLn(String(this.erosionLength));
         file.outTextLn(String(this.erosionIterations));
         file.outTextLn(String(this.erosionAmount));
         file.outTextLn(String(this.deconvolutionAmount));
         file.outTextLn(String(this.deconvolutionIterations));
         file.outTextLn(String(Number(this.deconvolutionDeringing)));
         file.outTextLn(String(this.deconvolutionGlobalDark));

         file.close();
      } catch (error) {
         console.warningln("Failed to save scriptConfigFile: " + error.message);
      }
   },

   loadPathFromFile: function () {
      try {
         if (File.exists(scriptConfigFile)) {
            let file = new File;
            // console.writeln("Reading config file: " + scriptConfigFile);
            file.openForReading(scriptConfigFile);
            let lines = File.readLines(scriptConfigFile);
            if (lines.length > 0) {
               this.maxDistortion = Number(lines[0].trim());
               this.sensitivity = Number(lines[1].trim());
               this.structureLayers = Number(lines[2].trim());
               this.xyStretch = Number(lines[3].trim());
               this.peakResponse = Number(lines[4].trim());
               this.SSminimumStarSize = Number(lines[5].trim());
               this.SSdenoiseFirst = Boolean(Number(lines[6].trim()));
               this.SSdenoiseWithNN = Boolean(Number(lines[7].trim()));
               this.SSdenoiseWithMMT = Boolean(Number(lines[8].trim()));
               this.replaceWithSS = Boolean(Number(lines[9].trim()));
               this.SSlinearCheckBox = Boolean(Number(lines[10].trim()));
               this.keepSyntheticStars = Boolean(Number(lines[11].trim()));
               this.recombinationMethod = String(lines[12].trim());
               this.SSrecombinationExtraPercent = Number(lines[13].trim());
               this.SSstarIntensityRange = Number(lines[14].trim());
               this.SSallowClusteredSources = Boolean(Number(lines[15].trim()));
               this.erosionLength = Number(lines[16].trim());
               this.erosionIterations = Number(lines[17].trim());
               this.erosionAmount = Number(lines[18].trim());
               this.deconvolutionAmount = Number(lines[19].trim());
               this.deconvolutionIterations = Number(lines[20].trim());
               this.deconvolutionDeringing = Boolean(Number(lines[21].trim()));
               this.deconvolutionGlobalDark = Number(lines[22].trim());
            }
            file.close();
         }
      } catch (error) {
         console.warningln("Failed to load scriptConfigFile: " + error.message);
      }
   }
};



// Dialog setup, image selection, etc.
function MainDialog() {
   this.__base__ = Dialog;
   this.__base__();

   console.hide();
   globalParameters.load();

   this.title = new Label(this);
   this.title.text = "Linear Deblur Analytic " + VERSION;
   this.title.textAlignment = TextAlign_Center;

   this.description = new TextBox(this);
   this.description.readOnly = true;
   this.description.height = 120;
   this.description.maxHeight = 120;
   this.description.text = "This script attempts to deal with the problem of elongated stars, such as one might get with cable drag. It determines a PSF on stars detected " +
      "with Pixinsight's Star Detector in the center of the " +
      "image. The median rotation angle is calculated and " +
      "the stars are removed from the image using StarNet2 and then rotated so that the elongated stars " +
      "are parallel with the horizontal plane. An analytic algorithm (either erosion or deconvolution) is applied to the horizontal blurring " +
      "with a number of prespecified iterations and a mask length. The stars are then " +
      "rotated back and then replaced on the starless image.\n\n" +
      "For this algorithm, the background is not deblurred.";
   this.description.setMinWidth(800);
   

   this.imageSelectionLabel = new Label(this);
   this.imageSelectionLabel.text = "Select Image:";
   this.imageSelectionLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

   this.imageSelectionDropdown = new ComboBox(this);
   this.imageSelectionDropdown.editEnabled = false;

   this.imageSelectionDropdown.onItemSelected = (index) => {
      if (index >= 0) {
         let window = ImageWindow.windowById(this.imageSelectionDropdown.itemText(index));
         if (window && !window.isNull) {
            globalParameters.targetWindow = window;
         } else {
            console.writeln("No valid window selected for preview!");
            
            this.adjustToContents();
         }
      }
   };

   let windows = ImageWindow.windows;
   let activeWindowId = ImageWindow.activeWindow.mainView.id;
   for (let i = 0; i < windows.length; ++i) {
      this.imageSelectionDropdown.addItem(windows[i].mainView.id);
      if (windows[i].mainView.id === activeWindowId) {
         this.imageSelectionDropdown.currentItem = i;
         globalParameters.targetWindow = windows[i];
      }
   }

   this.imageSelectionSizer = new HorizontalSizer;
   this.imageSelectionSizer.spacing = 4;
   this.imageSelectionSizer.add(this.imageSelectionLabel);
   this.imageSelectionSizer.add(this.imageSelectionDropdown, 100);

   var dlg = this;


   


   this.SSdenoiseFirst = new CheckBox(this);
   with (this.SSdenoiseFirst) {
      toolTip = "Denoising tends to increase the number of stars detected\nBoth tools can be used sequentially to improve star detection"
      text = "Denoise prior to detection";
      enabled = true;
      checked = globalParameters.SSdenoiseFirst;
      bindings = function () {
         this.checked = globalParameters.SSdenoiseFirst;
      }
      onCheck = function (value) {
         globalParameters.SSdenoiseFirst = value;
         dlg.SSdenoiseWithNN.enabled = value;
         dlg.SSdenoiseWithMMT.enabled = value;
      }
   }

   this.SSdenoiseWithNN = new CheckBox(this);
   with (this.SSdenoiseWithNN) {
      toolTip = "Denoise using machine language denoiser that comes with this script"
      text = "Denoise with ML denoiser";
      // enabled = globalParameters.SSdenoiseFirst;
      enabled = false;
      visible = false;
      checked = globalParameters.SSdenoiseWithNN;
      bindings = function () {
         this.checked = globalParameters.SSdenoiseWithNN;
      }
      onCheck = function (value) {
         globalParameters.SSdenoiseWithNN = value;
      }
   }

   this.SSdenoiseWithMMT = new CheckBox(this);
   with (this.SSdenoiseWithMMT) {
      toolTip = "Denoise using Multiscale Median Transform noise reduction"
      text = "Denoise with MMT";
      enabled = globalParameters.SSdenoiseFirst;
      checked = globalParameters.SSdenoiseWithMMT;
      bindings = function () {
         this.checked = globalParameters.SSdenoiseWithMMT;
      }
      onCheck = function (value) {
         globalParameters.SSdenoiseWithMMT = value;
      }
   }


   this.SSpreprocessGB = new GroupBox(this);
   with (this.SSpreprocessGB) {
      sizer = new HorizontalSizer;
      title = "Preprocessing";
      enabled = true;

      sizer.add(this.SSdenoiseFirst);
      sizer.spacing = 6;
      sizer.add(this.SSdenoiseWithNN);
      sizer.spacing = 6;
      sizer.add(this.SSdenoiseWithMMT);
      sizer.spacing = 6;
      sizer.addStretch();

   }


   this.syntheticStarsButtonTab = new PushButton(this);
   this.syntheticStarsButtonTab.text = "Test Star Detector";
   this.syntheticStarsButtonTab.onClick = function () {
      var parent = this.parent;
      var grandparent = parent.parent;
      var greatgrandparent = grandparent.parent;
      var useStarSizeRange = false;
      var filterByIntensity = false;
      let returnedStars = createSyntheticStars(globalParameters.targetWindow.mainView, dlg, useStarSizeRange, filterByIntensity, globalParameters.SSlinearCheckBox, globalParameters.SSdenoiseWithNN, globalParameters.SSdenoiseWithMMT, globalParameters.recombinationMethod, globalParameters.SSrecombinationExtraPercent, globalParameters.keepSyntheticStars, globalParameters.replaceWithSS);
      globalParameters.save();

      Console.writeln('Number of stars returned by detector: ' + returnedStars.length);
   };

   this.syntheticStarsButtonSizerTab = new HorizontalSizer;
   this.syntheticStarsButtonSizerTab.spacing = 4;
   this.syntheticStarsButtonSizerTab.add(this.syntheticStarsButtonTab);
   /*
   std.sensitivity = Math.pow(10.0, -5.0);
   std.xyStretch = 1.5;
   std.maxDistortion = 0.1;
   std.minStructSize = 0;
   */


   this.SSsensitivity = new NumericControl(this);
   this.SSsensitivity.label.text = "Sensitivity:";
   this.SSsensitivity.toolTip = "Increasing numbers increases the number of stars detected\nHigher numbers may erroneously detect non-star objects as stars";
   this.SSsensitivity.setRange(0, 1);
   this.SSsensitivity.setPrecision(2);
   this.SSsensitivity.setValue(globalParameters.sensitivity);
   this.SSsensitivity.onValueUpdated = (value) => {
      globalParameters.sensitivity = value;
   };

   this.SSsensitivitySizer = new HorizontalSizer;
   this.SSsensitivitySizer.spacing = 4;
   this.SSsensitivitySizer.add(this.SSsensitivity);

   this.SSstructureLayers = new NumericControl(this);
   this.SSstructureLayers.label.text = "Structure layers:";
   this.SSstructureLayers.toolTip = "Increasing numbers increases the number of stars detected\nHigher numbers may erroneously detect non-star objects as stars";
   this.SSstructureLayers.setRange(1, 12);
   this.SSstructureLayers.setPrecision(0);
   this.SSstructureLayers.setValue(globalParameters.structureLayers);
   this.SSstructureLayers.onValueUpdated = (value) => {
      globalParameters.structureLayers = value;
   };

   this.SSstructureLayersSizer = new HorizontalSizer;
   this.SSstructureLayersSizer.spacing = 4;
   this.SSstructureLayersSizer.add(this.SSstructureLayers);


   this.SSxyStretch = new NumericControl(this);
   this.SSxyStretch.label.text = "XY stretch:";
   this.SSxyStretch.toolTip = "Stretch factor for the barycenter search algorithm, in sigma units.\nIncrease it to make the algorithm more robust to nearby structures, \nsuch as multiple / crowded stars and small nebular features.\nHowever, too large of a stretch factor will make the algorithm less accurate.";
   this.SSxyStretch.setRange(1, 3);
   this.SSxyStretch.setPrecision(1);
   this.SSxyStretch.setValue(globalParameters.xyStretch);
   this.SSxyStretch.onValueUpdated = (value) => {
      globalParameters.xyStretch = value;
   };

   this.SSxyStretchSizer = new HorizontalSizer;
   this.SSxyStretchSizer.spacing = 4;
   this.SSxyStretchSizer.add(this.SSxyStretch);

   this.SSpeakResponse = new NumericControl(this);
   this.SSpeakResponse.label.text = "Peak response:";
   this.SSpeakResponse.toolTip = "If you decrease this parameter, stars will need to have stronger(or more prominent) \npeaks to be detected.This is useful to prevent detection of saturated stars, \nas well as small nonstellar features.By increasing this parameter, \nthe star detection algorithm will be more sensitive to peakedness, \nand hence more tolerant with relatively flat image features.\n\nA higher number detects more objects.";
   this.SSpeakResponse.setRange(0, 1);
   this.SSpeakResponse.setPrecision(2);
   this.SSpeakResponse.setValue(globalParameters.peakResponse);
   this.SSpeakResponse.onValueUpdated = (value) => {
      globalParameters.peakResponse = value;
   };

   this.SSpeakResponseSizer = new HorizontalSizer;
   this.SSpeakResponseSizer.spacing = 4;
   this.SSpeakResponseSizer.add(this.SSpeakResponse);


   this.SSminimumStarSize = new NumericControl(this);
   this.SSminimumStarSize.label.text = "Min star size:";
   this.SSminimumStarSize.toolTip = "If you decrease this parameter, smaller star will be included by the size specified.\nIf you increase the parameter, smaller stars will be excluded.\nThis might be useful to exclude small stars erroneously detected from noise.";
   this.SSminimumStarSize.setRange(0, 100);
   this.SSminimumStarSize.setPrecision(0);
   this.SSminimumStarSize.setValue(globalParameters.SSminimumStarSize);
   this.SSminimumStarSize.onValueUpdated = (value) => {
      globalParameters.SSminimumStarSize = value;
   };

   this.SSminimumStarSizeSizer = new HorizontalSizer;
   this.SSminimumStarSizeSizer.spacing = 4;
   this.SSminimumStarSizeSizer.add(this.SSminimumStarSize);





   this.SSmaxDistortion = new NumericControl(this);
   this.SSmaxDistortion.label.text = "Max distortion:";
   this.SSmaxDistortion.toolTip = "Use this parameter, if necessary, to control inclusion of elongated stars, \ncomplex clusters of stars, and nonstellar image features.";
   this.SSmaxDistortion.setRange(0, 1);
   this.SSmaxDistortion.setPrecision(2);
   // this.SSmaxDistortion.slider.setRange(0, 1);
   // this.SSmaxDistortion.setValue(0.4);
   this.SSmaxDistortion.setValue(globalParameters.maxDistortion);
   // this.starSizeSlider.hide(); // Hide initially
   this.SSmaxDistortion.onValueUpdated = (value) => {
      globalParameters.maxDistortion = value;
   };

   this.SSmaxDistortionSizer = new HorizontalSizer;
   this.SSmaxDistortionSizer.spacing = 4;
   this.SSmaxDistortionSizer.add(this.SSmaxDistortion);


   this.ignoreHotPixels = new CheckBox(this);
   with (this.ignoreHotPixels) {
      toolTip = "Check if you want the star detector to ignore hot pixels"
      text = "Ignore hot pixels";
      enabled = true;
      checked = globalParameters.ignoreHotPixels;
      bindings = function () {
         this.checked = globalParameters.ignoreHotPixels;
      }
      onCheck = function (value) {
         globalParameters.ignoreHotPixels = value;
      }
   }

   this.SSallowClusteredSources = new CheckBox(this);
   with (this.SSallowClusteredSources) {
      toolTip = "Check if you want the star detector to allow the detection of closely-clustered stars as one large star.\nUnchecking ignores the cluster completely."
      text = "Allow Clustered Sources";
      enabled = true;
      checked = globalParameters.SSallowClusteredSources;
      bindings = function () {
         this.checked = globalParameters.SSallowClusteredSources;
      }
      onCheck = function (value) {
         globalParameters.SSallowClusteredSources = value;
      }
   }

   this.SSdetectorCheckBoxesSizer = new HorizontalSizer;
   this.SSdetectorCheckBoxesSizer.spacing = 4;
   this.SSdetectorCheckBoxesSizer.add(this.ignoreHotPixels);
   this.SSdetectorCheckBoxesSizer.add(this.SSallowClusteredSources);
   this.SSdetectorCheckBoxesSizer.addStretch();




   this.SSstarDetectionGB = new GroupBox(this);
   with (this.SSstarDetectionGB) {
      sizer = new VerticalSizer;
      title = "Star Detection";
      enabled = true;

      sizer.add(this.SSsensitivitySizer);
      sizer.spacing = 6;
      sizer.add(this.SSstructureLayersSizer);
      sizer.spacing = 6;
      sizer.add(this.SSxyStretchSizer);
      sizer.spacing = 6;
      sizer.add(this.SSmaxDistortionSizer);
      sizer.spacing = 6;
      sizer.add(this.SSpeakResponseSizer);
      sizer.spacing = 6;
      sizer.add(this.SSminimumStarSizeSizer);
      sizer.spacing = 6;
      sizer.add(this.SSdetectorCheckBoxesSizer);
      sizer.spacing = 6;
      sizer.addStretch();

   }


   this.replaceWithSS = new CheckBox(this);
   with (this.replaceWithSS) {
      toolTip = "Check if you want to use StarNet2 to replace the stars on the image with the synthetic stars"
      text = "Replace stars with synthetic stars";
      enabled = true;
      checked = globalParameters.replaceWithSS;
      bindings = function () {
         this.checked = globalParameters.replaceWithSS;
      }
      onCheck = function (value) {
         globalParameters.replaceWithSS = value;
      }
   }

   this.keepSyntheticStars = new CheckBox(this);
   with (this.keepSyntheticStars) {
      toolTip = "Check if you want to keep the generated synthetic stars image"
      text = "Keep synthetic stars image";
      enabled = true;
      checked = globalParameters.keepSyntheticStars;
      bindings = function () {
         this.checked = globalParameters.keepSyntheticStars;
      }
      onCheck = function (value) {
         globalParameters.keepSyntheticStars = value;
      }
   }

   this.SSlinearCheckBox = new CheckBox(this);
   with (this.SSlinearCheckBox) {
      toolTip = "Check if this is a linear image for star replacement with StarNet2"
      text = "Linear data";
      enabled = true;
      checked = globalParameters.SSlinearCheckBox;
      bindings = function () {
         this.checked = globalParameters.SSlinearCheckBox;
      }
      onCheck = function (value) {
         globalParameters.SSlinearCheckBox = value;
      }
   }


   this.recombinationMethodComboBox = new ComboBox(this);
   this.recombinationMethodComboBox.toolTip = "Select the method by which the stars are recombined with the starless image\nThe recombination method uses PixelMath\nmaximum uses max(starless,stars)\nop_screen uses combine(starless,stars,op_screen())";
   this.recombinationMethodComboBox.addItem("maximum");
   this.recombinationMethodComboBox.addItem("op_screen");

   if (globalParameters.recombinationMethod === 'op_screen') {
      this.recombinationMethodComboBox.currentItem = 1;
   }
   else {
      this.recombinationMethodComboBox.currentItem = 0;
   }

   this.recombinationMethodComboBox.onItemSelected = (index) => {
      // console.writeln("Setting stride size index: " + index + " from stored: " + globalParameters.strideSize);
      if (index == 0) {
         globalParameters.recombinationMethod = 'maximum';
      }
      else {
         globalParameters.recombinationMethod = 'op_screen';
      }

      // globalParameters.save();
   };



   this.SSrecombinationExtraPercent = new NumericControl(this);
   this.SSrecombinationExtraPercent.label.text = "Recombination factor:";
   this.SSrecombinationExtraPercent.toolTip = "This will add a percentage amount to the peak value to enhance the star above background,\nbut only if the maximum method of recombination is selected.\nThis may be useful for faint stars with peaks close to background\nWarning - at baseline, the algorithm detects and creates stars with their original\ndetected parameters. Using amounts above 0 will make stars more visible, but will\nincrease their maximum peak values on the replaced image.";
   this.SSrecombinationExtraPercent.setRange(0, 1);
   this.SSrecombinationExtraPercent.setPrecision(2);
   // this.SSmaxDistortion.slider.setRange(0, 1);
   // this.SSmaxDistortion.setValue(0.4);
   this.SSrecombinationExtraPercent.setValue(globalParameters.SSrecombinationExtraPercent);
   // this.starSizeSlider.hide(); // Hide initially
   this.SSrecombinationExtraPercent.onValueUpdated = (value) => {
      globalParameters.SSrecombinationExtraPercent = value;
   };

   this.SSrecombinationExtraPercentSizer = new HorizontalSizer;
   this.SSrecombinationExtraPercentSizer.spacing = 4;
   this.SSrecombinationExtraPercentSizer.add(this.SSrecombinationExtraPercent);



   this.SSpostprocessGB = new GroupBox(this);
   with (this.SSpostprocessGB) {
      sizer = new HorizontalSizer;
      title = "Postprocessing";
      enabled = true;

      sizer.add(this.SSlinearCheckBox);
      sizer.spacing = 6;
      sizer.add(this.replaceWithSS);
      sizer.spacing = 6;
      sizer.add(this.keepSyntheticStars);
      sizer.spacing = 6;
      sizer.add(this.recombinationMethodComboBox);
      sizer.spacing = 6;
      sizer.add(this.SSrecombinationExtraPercentSizer);
      sizer.spacing = 6;
      sizer.addStretch();

   }

   this.syntheticStarsGeneratorTab = new Control(this);

   with (this.syntheticStarsGeneratorTab) {
      sizer = new VerticalSizer(this.syntheticStarsGeneratorTab);
      // sizer = new HorizontalSizer;

      sizer.add(this.SSpreprocessGB);
      sizer.spacing = 6;
      sizer.add(this.SSstarDetectionGB);
      sizer.spacing = 6;
      sizer.add(this.SSpostprocessGB);
      sizer.spacing = 6;
      sizer.add(this.syntheticStarsButtonSizerTab);
      sizer.spacing = 6;

      sizer.addStretch();
   }






   this.LinearDeblurAnalyticTab = new Control(this);

   this.LinearDeblurAnalyticDescription = new TextBox(this);
   this.LinearDeblurAnalyticDescription.readOnly = true;
   this.LinearDeblurAnalyticDescription.height = 220;
   this.LinearDeblurAnalyticDescription.maxHeight = 220;
   this.LinearDeblurAnalyticDescription.text = "This tab deblurs the stars using an analytic algorithm. It uses StarNet2 at a certain stage, which must be installed, and it helps significantly with the speed of the algorithm if a " +
      "GPU is available.\n\nIt works on linear and nonlinear images as well as mono, RGB/3 channel images, and drizzle images (would recommend starting with doubling " +
      "the typical erosion amount for drizzled images).\n\n" +
      "If the deconvolution length is too long, there may be some ringing effects seen on the stars. A deringing option is available, although the results seem better if the erosion length is reduce and the iterations are adjusted.\n\n" +
      "If the image is linear, the Linear data checkbox should be checked to reduce artifacts.";

   this.linearCheckBox = new CheckBox(this);
   with (this.linearCheckBox) {
      toolTip = "Check if this is a linear image to optimize star detection"
      text = "Linear data";
      enabled = true;
      checked = globalParameters.linearImage;
      bindings = function () {
         this.checked = globalParameters.linearImage;
      }
      onCheck = function (value) {
         globalParameters.linearImage = value;
      }
   }

   this.erosionLength = new NumericControl(this);
   this.erosionLength.label.text = "Erosion length:";
   this.erosionLength.setRange(2, 11);
   this.erosionLength.setPrecision(0);
   this.erosionLength.setValue(globalParameters.erosionLength);
   this.erosionLength.onValueUpdated = (value) => {
      globalParameters.erosionLength = value;
   };

   this.erosionLengthSizer = new HorizontalSizer;
   this.erosionLengthSizer.spacing = 4;
   this.erosionLengthSizer.add(this.erosionLength);

   this.erosionIterations = new NumericControl(this);
   this.erosionIterations.label.text = "Iterations:";
   this.erosionIterations.setRange(1, 5);
   this.erosionIterations.setPrecision(0);
   this.erosionIterations.setValue(globalParameters.erosionIterations);
   this.erosionIterations.onValueUpdated = (value) => {
      globalParameters.erosionIterations = value;
   };

   this.erosionIterationsSizer = new HorizontalSizer;
   this.erosionIterationsSizer.spacing = 4;
   this.erosionIterationsSizer.add(this.erosionIterations);

   this.erosionAmount = new NumericControl(this);
   this.erosionAmount.label.text = "Erosion amount:";
   this.erosionAmount.setRange(0, 1);
   this.erosionAmount.setPrecision(2);
   this.erosionAmount.setValue(globalParameters.erosionAmount);
   this.erosionAmount.onValueUpdated = (value) => {
      globalParameters.erosionAmount = value;
   };

   this.erosionAmountSizer = new HorizontalSizer;
   this.erosionAmountSizer.spacing = 4;
   this.erosionAmountSizer.add(this.erosionAmount);

   this.deconvolutionAmount = new NumericControl(this);
   this.deconvolutionAmount.label.text = "Deconvolution amount:";
   this.deconvolutionAmount.setRange(2, 11);
   this.deconvolutionAmount.setPrecision(0);
   this.deconvolutionAmount.setValue(globalParameters.deconvolutionAmount);
   this.deconvolutionAmount.onValueUpdated = (value) => {
      globalParameters.deconvolutionAmount = value;
   };

   this.deconvolutionAmountSizer = new HorizontalSizer;
   this.deconvolutionAmountSizer.spacing = 4;
   this.deconvolutionAmountSizer.add(this.deconvolutionAmount);

   this.deconvolutionIterations = new NumericControl(this);
   this.deconvolutionIterations.label.text = "Deconvolution iterations:";
   this.deconvolutionIterations.setRange(1, 50);
   this.deconvolutionIterations.setPrecision(0);
   this.deconvolutionIterations.setValue(globalParameters.deconvolutionIterations);
   this.deconvolutionIterations.onValueUpdated = (value) => {
      globalParameters.deconvolutionIterations = value;
   };

   this.deconvolutionIterationsSizer = new HorizontalSizer;
   this.deconvolutionIterationsSizer.spacing = 4;
   this.deconvolutionIterationsSizer.add(this.deconvolutionIterations);


   this.deconvolutionGlobalDark = new NumericControl(this);
   this.deconvolutionGlobalDark.label.text = "Global Dark:";
   this.deconvolutionGlobalDark.setRange(0, 1);
   this.deconvolutionGlobalDark.setPrecision(2);
   this.deconvolutionGlobalDark.setValue(globalParameters.deconvolutionGlobalDark);
   this.deconvolutionGlobalDark.onValueUpdated = (value) => {
      globalParameters.deconvolutionGlobalDark = value;
   };
   this.deconvolutionGlobalDark.enabled = globalParameters.deconvolutionDeringing;

   this.deconvolutionGlobalDarkSizer = new HorizontalSizer;
   this.deconvolutionGlobalDarkSizer.spacing = 4;
   this.deconvolutionGlobalDarkSizer.add(this.deconvolutionGlobalDark);



   this.ringingCheckBox = new CheckBox(this);
   with (this.ringingCheckBox) {
      toolTip = "Check if this is a linear image to optimize star detection"
      text = "Deringing";
      enabled = true;
      checked = globalParameters.deconvolutionDeringing;
      bindings = function () {
         this.checked = globalParameters.deconvolutionDeringing;
      }
      onCheck = function (value) {
         globalParameters.deconvolutionDeringing = value;
         dlg.deconvolutionGlobalDark.enabled = globalParameters.deconvolutionDeringing;
      }
   }

   this.deblurMorphButtonTab = new PushButton(this);
   this.deblurMorphButtonTab.text = "Deblur using Erosion";
   this.deblurMorphButtonTab.onClick = function () {
      var parent = this.parent;
      var grandparent = parent.parent;
      var greatgrandparent = grandparent.parent;
      var greatgreatgrandparent = greatgrandparent.parent;
      let returnedDenoise = deblurAnalyticImage(globalParameters.targetWindow.mainView, greatgreatgrandparent, DEBLUR_ERODE);
      globalParameters.save();

      Console.writeln('Image deblurred');
   };

   this.deblurMorphButtonSizerTab = new HorizontalSizer;
   this.deblurMorphButtonSizerTab.spacing = 4;
   this.deblurMorphButtonSizerTab.add(this.deblurMorphButtonTab);


   this.deblurDeconButton = new PushButton(this);
   this.deblurDeconButton.text = "Deblur using Deconvolution";
   this.deblurDeconButton.onClick = function () {
      var parent = this.parent;
      var grandparent = parent.parent;
      var greatgrandparent = grandparent.parent;
      var greatgreatgrandparent = greatgrandparent.parent;
      let returnedDenoise = deblurAnalyticImage(globalParameters.targetWindow.mainView, greatgreatgrandparent, DEBLUR_DECON);
      globalParameters.save();

      Console.writeln('Image deblurred');
   };

   this.deblurDeconButtonSizer = new HorizontalSizer;
   this.deblurDeconButtonSizer.spacing = 4;
   this.deblurDeconButtonSizer.add(this.deblurDeconButton);



   this.erosionGroupBox = new GroupBox(this);
   with (this.erosionGroupBox) {
      sizer = new VerticalSizer;
      title = "Deblur using erosion";
      enabled = true;

      sizer.add(this.erosionLengthSizer);
      sizer.spacing = 6;
      sizer.add(this.erosionIterationsSizer);
      sizer.spacing = 6;
      sizer.add(this.erosionAmountSizer);
      sizer.spacing = 6;
      sizer.addStretch();
      sizer.add(this.deblurMorphButtonSizerTab);

   }

   this.deconvolutionGroupBox = new GroupBox(this);
   with (this.deconvolutionGroupBox) {
      sizer = new VerticalSizer;
      title = "Deblur using deconvolution";
      enabled = true;

      sizer.add(this.deconvolutionAmountSizer);
      sizer.spacing = 6;
      sizer.add(this.deconvolutionIterationsSizer);
      sizer.spacing = 6;
      sizer.add(this.ringingCheckBox);
      sizer.spacing = 6;
      sizer.add(this.deconvolutionGlobalDarkSizer);
      sizer.spacing = 6;
      sizer.add(this.deblurDeconButtonSizer);
      sizer.spacing = 6;
      sizer.addStretch();
   }









   this.deblurAlgorithmHorizontalSizer = new HorizontalSizer;
   this.deblurAlgorithmHorizontalSizer.spacing = 4;
   this.deblurAlgorithmHorizontalSizer.add(this.erosionGroupBox);
   this.deblurAlgorithmHorizontalSizer.add(this.deconvolutionGroupBox);



   with (this.LinearDeblurAnalyticTab) {
      sizer = new VerticalSizer(this.LinearDeblurAnalyticTab);
      // sizer = new HorizontalSizer;
      sizer.add(this.LinearDeblurAnalyticDescription);
      sizer.spacing = 6;
      sizer.add(this.linearCheckBox);
      sizer.spacing = 6;
      sizer.add(this.deblurAlgorithmHorizontalSizer);
      sizer.spacing = 6;
      sizer.addStretch();
   }















   this.deblurTabBox = new TabBox(this);
   with (this.deblurTabBox) {

      addPage(this.LinearDeblurAnalyticTab, "Linear Deblur Analytic");
      addPage(this.syntheticStarsGeneratorTab, "Star Detector Settings");

      this.deblurTabBox.bindings = function () {
         this.enabled = globalParameters.targetView != null;
      }
   }




   this.lblState = new Label(this);
   this.lblState.text = "";

   this.lblStateSizer = new HorizontalSizer;
   this.lblStateSizer.spacing = 4;
   this.lblStateSizer.add(this.lblState);

   var progressValue = 0;

   this.progressBar = new Label(this);
   with (this.progressBar) {
      lineWidth = 1;
      frameStyle = FrameStyle_Box;
      textAlignment = TextAlign_Center | TextAlign_VertCenter;

      onPaint = function (x0, y0, x1, y1) {
         var g = new Graphics(dlg.progressBar);
         g.fillRect(x0, y0, x1, y1, new Brush(0xFFFFFFFF));
         if (progressValue > 0) {
            var l = (x1 - x0 + 1) * progressValue;
            g.fillRect(x0, y0, l, y1, new Brush(0xFF00EFE0));
         }
         g.end();
         text = (progressValue * 100).toFixed(0) + "%";
      }
   }

   this.progress = function (n) {
      progressValue = n;// Math.min(n, 1);
      dlg.progressBar.repaint();
   }


   // New Instance button
   this.newInstanceButton = new ToolButton(this);
   this.newInstanceButton.icon = this.scaledResource(":/process-interface/new-instance.png");
   this.newInstanceButton.setScaledFixedSize(24, 24);
   this.newInstanceButton.toolTip = "Save a new instance of this script";
   this.newInstanceButton.onMousePress = function () {
      this.dialog.newInstance();
   }.bind(this);

   this.undoRepairButton = new PushButton(this);
   this.undoRepairButton.text = "Undo";
   this.undoRepairButton.toolTip = "Undo the last repair";
   this.undoRepairButton.icon = ":/icons/undo.png";
   this.undoRepairButton.onClick = () => {
      if (globalParameters.targetWindow && !globalParameters.targetWindow.isNull) {
         globalParameters.targetWindow.undo();
      } else {
         console.writeln("No valid window selected for undo!");
      }
   };

   this.redoRepairButton = new PushButton(this);
   this.redoRepairButton.text = "Redo";
   this.redoRepairButton.toolTip = "Redo the last repair";
   this.redoRepairButton.icon = ":/icons/redo.png";
   this.redoRepairButton.onClick = () => {
      if (globalParameters.targetWindow && !globalParameters.targetWindow.isNull) {
         globalParameters.targetWindow.redo();
      } else {
         console.writeln("No valid window selected for redo!");
      }
   };

   this.buttonsSizer = new HorizontalSizer;
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add(this.newInstanceButton);
   // this.buttonsSizer.add(this.setupButton);
   this.buttonsSizer.addStretch();
   this.buttonsSizer.add(this.undoRepairButton);
   this.buttonsSizer.spacing = 6;
   this.buttonsSizer.add(this.redoRepairButton);
   this.buttonsSizer.addStretch();


   this.buttonsSizer.addStretch();

   // Layout
   this.sizer = new VerticalSizer;
   this.sizer.margin = 6;
   this.sizer.spacing = 6;
   this.sizer.addStretch();
   this.sizer.add(this.title);
   this.sizer.add(this.description);
   this.sizer.addStretch();
   this.sizer.add(this.imageSelectionSizer);
   this.sizer.spacing = 6;
   this.sizer.add(this.deblurTabBox);
   this.sizer.spacing = 6;

   this.sizer.add(this.lblStateSizer);
   this.sizer.spacing = 8;
   this.sizer.add(this.progressBar);
   this.sizer.spacing = 6;

   this.sizer.addStretch();


   this.sizer.addSpacing(12);
   this.sizer.add(this.buttonsSizer);

   this.windowTitle = "Linear Deblur Analytic Script";
   this.adjustToContents();


}


MainDialog.prototype = new Dialog;


// Main execution block for running the script
let dialog = new MainDialog();
console.show();
console.writeln("MainDialog process started.");
console.flush();

if (dialog.execute()) {
   let selectedIndex = dialog.imageSelectionDropdown.currentItem;
   let selectedView = ImageWindow.windows[selectedIndex];

   if (!selectedView) {
      console.criticalln("Please select an image.");
   } else {
       let artifactCorrectionFileWindow = ImageWindow.open(globalParameters.artifactCorrectionImageFile)[0];
      if (artifactCorrectionFileWindow) {
         artifactCorrectionFileWindow.show();
      }
   }
}


// -------------------------------------------------------------------------------------------------




function deblurAnalyticImage(view, dlg, deblur_mode) {
   var originalImageWidth = view.image.width;
   var originalImageHeight = view.image.height;

   let cropImageWindow = new ImageWindow(view.image.width, view.image.height,
      view.image.numberOfChannels, // 1 channel for grayscale
      view.image.bitsPerSample,
      view.image.isReal,
      view.image.isColor
   );

   Console.writeln("New stars window has been setup");

   let cropImageView = cropImageWindow.mainView;
   cropImageView.beginProcess(UndoFlag_NoSwapFile);
   let cropImage = cropImageView.image;
   cropImage.apply(view.image); // Initialize the inverted mask image

   const midImageCropSize = 1024;

   // image width
   // var cropWidth = -1 * Math.floor((view.image.width - midImageCropSize) / 2);
   // var cropHeight = -1 * Math.floor((view.image.height - midImageCropSize) / 2);

   var cropPercentage = 0.25;

   var cropWidth = -1 * Math.floor(view.image.width * cropPercentage);
   var cropHeight = -1 * Math.floor(view.image.height * cropPercentage);

   var P = new Crop;
   P.leftMargin = cropWidth;
   P.topMargin = cropHeight;
   P.rightMargin = cropWidth;
   P.bottomMargin = cropHeight;
   P.mode = Crop.prototype.AbsolutePixels;
   P.xResolution = 72.000;
   P.yResolution = 72.000;
   P.metric = false;
   P.forceResolution = false;
   P.red = 0.000000;
   P.green = 0.000000;
   P.blue = 0.000000;
   P.alpha = 1.000000;
   P.noGUIMessages = false;

   P.executeOn(cropImageView);

   cropImageWindow.show();

   var stars = getStars(cropImageView, dlg);

   Console.writeln('Number of stars detected by detector function: ' + stars.length);

   var starStats = getStarStats(stars);

   let medianTheta = starStats[0];
   let medianSX = starStats[1];
   let medianSY = starStats[2];

   Console.writeln("Median theta: " + medianTheta + " sx: " + medianSX + " sy: " + medianSY);

   var blurAmount = medianSX - medianSY;

   dlg.lblState.text = 'Found stars rotated at angle ' + medianTheta + ' - removing stars using StarNet2';
   processEvents();

   let replacementImageWindow = new ImageWindow(view.image.width, view.image.height,
      view.image.numberOfChannels, // 1 channel for grayscale
      view.image.bitsPerSample,
      view.image.isReal,
      view.image.isColor
   );

   let replacementImageView = replacementImageWindow.mainView;
   replacementImageView.beginProcess(UndoFlag_NoSwapFile);
   let replacementImageImage = replacementImageView.image;
   replacementImageImage.apply(view.image);
   
   replacementImageView.window.show();

   var PSN = new StarNet2;
   PSN.stride = StarNet2.prototype.defStride;
   PSN.mask = true;
   PSN.linear = globalParameters.linearImage;
   PSN.upsample = false;
   PSN.shadows_clipping = -2.80;
   PSN.target_background = 0.25;

   PSN.executeOn(replacementImageView);

   dlg.lblState.text = 'StarNet2 operation completed - rotating star_mask image';
   processEvents();

   let starMaskView = View.viewById('star_mask');


   Console.writeln("Ready to rotate");

   var pi = Math.PI;
   // Multiply degrees by pi divided by 180 to convert to radians.
   var radiansToRotate = -1 * medianTheta * (pi / 180);

   var P = new Rotation;
   P.angle = radiansToRotate;
   P.optimizeFast = true;
   P.interpolation = Rotation.prototype.Auto;
   P.clampingThreshold = 0.30;
   P.smoothness = 1.50;
   P.gammaCorrection = false;
   P.red = 0.000000;
   P.green = 0.000000;
   P.blue = 0.000000;
   P.alpha = 1.000000;
   P.noGUIMessages = false;

   P.executeOn(starMaskView);

   Console.writeln("Rotated: " + radiansToRotate);

   /*
   if (view.computeOrFetchProperty("Median").at(0) < 0.1) {
       let result = dialog.showWarningDialog("Median lower 0.1. Unlikely this is a linear image. This script only works on non-linear images.", "Failed to load", "Continue anyway", true);
       if (result != 1) {
           dialog.mainViewSelector.remove(view);
           CurrentProcessingInfo.mainViewId = null;
           return;
       }
   }
   */

   if (deblur_mode == DEBLUR_ERODE) {
      dlg.lblState.text = 'Stars rotated - now deblurring using erosion';
      processEvents();
   }
   else {
      dlg.lblState.text = 'Stars rotated - now deblurring using deconvolution';
      processEvents();
   }





   if (deblur_mode == DEBLUR_ERODE) {
      var PMorph = new MorphologicalTransformation;
      PMorph.operator = MorphologicalTransformation.prototype.Erosion;
      PMorph.interlacingDistance = 1;
      PMorph.lowThreshold = 0.000000;
      PMorph.highThreshold = 0.000000;
      PMorph.numberOfIterations = globalParameters.erosionIterations;
      PMorph.amount = globalParameters.erosionAmount;
      PMorph.selectionPoint = 0.50;
      PMorph.structureName = "";


      if (globalParameters.erosionLength == 2) {
         PMorph.structureSize = 3;
         PMorph.structureWayTable = [ // mask
            [[
               0x00, 0x00, 0x00,
               0x00, 0x01, 0x01,
               0x00, 0x00, 0x00
            ]]
         ];
      }
      else if (globalParameters.erosionLength == 3) {
         PMorph.structureSize = 3;
         PMorph.structureWayTable = [ // mask
            [[
               0x00, 0x00, 0x00,
               0x01, 0x01, 0x01,
               0x00, 0x00, 0x00
            ]]
         ];
      }
      else if (globalParameters.erosionLength == 4) {
         PMorph.structureSize = 5;
         PMorph.structureWayTable = [ // mask
            [[
               0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00,
               0x01, 0x01, 0x01, 0x01, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00
            ]]
         ];
      }
      else if (globalParameters.erosionLength == 5) {
         PMorph.structureSize = 5;
         PMorph.structureWayTable = [ // mask
            [[
               0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00,
               0x01, 0x01, 0x01, 0x01, 0x01,
               0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00
            ]]
         ];
      }
      else if (globalParameters.erosionLength == 6) {
         PMorph.structureSize = 7;
         PMorph.structureWayTable = [ // mask
            [[
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
         ];
      }
      else if (globalParameters.erosionLength == 7) {
         PMorph.structureSize = 7;
         PMorph.structureWayTable = [ // mask
            [[
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
         ];
      }
      else if (globalParameters.erosionLength == 8) {
         PMorph.structureSize = 9;
         PMorph.structureWayTable = [ // mask
            [[
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
         ];
      }
      else if (globalParameters.erosionLength == 9) {
         PMorph.structureSize = 9;
         PMorph.structureWayTable = [ // mask
            [[
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
         ];
      }
      else if (globalParameters.erosionLength == 10) {
         PMorph.structureSize = 11;
         PMorph.structureWayTable = [ // mask
            [[
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
         ];
      }
      else {
         PMorph.structureSize = 11;
         PMorph.structureWayTable = [ // mask
            [[
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
               0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
            ]]
         ];
      }

      Console.writeln("Erosion matrix: " + PMorph.structureWayTable);

      PMorph.executeOn(starMaskView);

      dlg.lblState.text = 'Deblurred using morphological erosion with amount: ' + globalParameters.erosionAmount + ' - now recombiing';
      processEvents();
   }
   else if (deblur_mode == DEBLUR_DECON) {
      var P = new Deconvolution;
      P.algorithm = Deconvolution.prototype.RichardsonLucy;
      P.numberOfIterations = globalParameters.deconvolutionIterations;
      P.deringing = globalParameters.deconvolutionDeringing;
      P.deringingDark = globalParameters.deconvolutionGlobalDark;
      P.deringingBright = 0.0000;
      P.deringingSupport = false;
      P.deringingSupportAmount = 0.70;
      P.deringingSupportViewId = "";
      P.toLuminance = true;
      P.psfMode = Deconvolution.prototype.MotionBlur;
      P.psfSigma = 2.00;
      P.psfShape = 2.00;
      P.psfAspectRatio = 1.00;
      P.psfRotationAngle = 0.00;
      P.psfMotionLength = globalParameters.deconvolutionAmount;
      P.psfMotionRotationAngle = 0.00;
      P.psfViewId = "";
      P.psfFFTSizeLimit = 15;
      P.useRegularization = true;
      P.waveletLayers = [ // noiseThreshold, noiseReduction
         [3.00, 1.00],
         [2.00, 0.70],
         [1.00, 0.70],
         [1.00, 0.70],
         [1.00, 0.70]
      ];
      P.noiseModel = Deconvolution.prototype.Gaussian;
      P.numberOfWaveletLayers = 2;
      P.scalingFunction = Deconvolution.prototype.B3Spline5x5;
      P.convergence = 0.0000;
      P.rangeLow = 0.0000000;
      P.rangeHigh = 0.0000000;
      P.iterations = [ // count
         [0],
         [0],
         [0]
      ];

      Console.writeln("Deblur deconvolution size: " + globalParameters.deconvolutionAmount);

      P.executeOn(starMaskView);

      dlg.lblState.text = 'Deblurred using deconvolution with amount: ' + globalParameters.deconvolutionAmount + ' and iterations: ' + globalParameters.deconvolutionIterations + ' - now recombiing';
      processEvents();
   }

   dlg.lblState.text = 'Deblurred - rotating star_mask back';
   processEvents();

   radiansToRotate = medianTheta * (pi / 180);

   var P = new Rotation;
   P.angle = radiansToRotate;
   P.optimizeFast = true;
   P.interpolation = Rotation.prototype.Auto;
   P.clampingThreshold = 0.30;
   P.smoothness = 1.50;
   P.gammaCorrection = false;
   P.red = 0.000000;
   P.green = 0.000000;
   P.blue = 0.000000;
   P.alpha = 1.000000;
   P.noGUIMessages = false;

   P.executeOn(starMaskView);

   dlg.lblState.text = 'Rotated back - cropping star_mask to fit starless image';
   processEvents();


   Console.writeln("Rotated back: " + radiansToRotate);

   cropWidth = -1 * Math.floor((starMaskView.image.width - originalImageWidth) / 2);
   cropHeight = -1 * Math.floor((starMaskView.image.height - originalImageHeight) / 2);

   var cropWidthRight = -1 * (starMaskView.image.width - (originalImageWidth - cropWidth));
   var cropWidthBottom = -1 * (starMaskView.image.height - (originalImageHeight - cropHeight));

   Console.writeln("originalImageWidth: " + originalImageWidth + ' originalImageHeight: ' + originalImageHeight);
   Console.writeln("current image width: " + starMaskView.image.width + ' current image height: ' + starMaskView.image.height);
   Console.writeln("cropWidth: " + cropWidth + ' cropHeight: ' + cropHeight + "cropWidthRight: " + cropWidthRight + ' cropHeightBottom: ' + cropWidthBottom);

   var P = new Crop;
   P.leftMargin = cropWidth;
   P.topMargin = cropHeight;
   P.rightMargin = cropWidthRight;
   P.bottomMargin = cropWidthBottom;
   P.mode = Crop.prototype.AbsolutePixels;
   P.xResolution = 72.000;
   P.yResolution = 72.000;
   P.metric = false;
   P.forceResolution = false;
   P.red = 0.000000;
   P.green = 0.000000;
   P.blue = 0.000000;
   P.alpha = 1.000000;
   P.noGUIMessages = false;

   P.executeOn(starMaskView);

   dlg.lblState.text = 'Recropped star_mask - recombining star_mask with starless image';
   processEvents();

   var P = new PixelMath;
   P.expression = "combine(" + replacementImageView.id + "," + starMaskView.id + ",op_screen())";
   P.expression1 = "";
   P.expression2 = "";
   P.expression3 = "";
   P.useSingleExpression = true;
   P.symbols = "";
   P.clearImageCacheAndExit = false;
   P.cacheGeneratedImages = false;
   P.generateOutput = true;
   P.singleThreaded = false;
   P.optimization = true;
   P.use64BitWorkingImage = false;
   P.rescale = false;
   P.rescaleLower = 0;
   P.rescaleUpper = 1;
   P.truncate = true;
   P.truncateLower = 0;
   P.truncateUpper = 1;
   P.createNewImage = false;
   P.showNewImage = true;
   P.newImageId = "";
   P.newImageWidth = 0;
   P.newImageHeight = 0;
   P.newImageAlpha = false;
   P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
   P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

   P.executeOn(replacementImageView);

   P.expression = "" + replacementImageView.id + "";

   P.executeOn(view);

   dlg.lblState.text = 'Deblurred process complete';
   processEvents();



   cropImageWindow.forceClose();
   starMaskView.window.forceClose();
   replacementImageWindow.forceClose();




   return stars;
}



